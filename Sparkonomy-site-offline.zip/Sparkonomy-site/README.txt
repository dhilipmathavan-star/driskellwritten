Double-click index.html to open the site in your browser.

Keep all files in this folder together.
